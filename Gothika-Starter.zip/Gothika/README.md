# Gothika — YouTube account-linking starter

This is the first backend foundation for Gothika. It provides Google OAuth sign-in and private-account API endpoints for the connected YouTube account.

## Included now

- Google OAuth using the official YouTube read-only scope.
- Encrypted storage for the OAuth token file (AES-256-GCM).
- Connected-account status.
- Personal playlists.
- Personal channel subscriptions.
- Disconnect endpoint.

## Important before deployment

This is a backend starter, not yet the finished Nuvio/Stremio add-on. The app-specific catalogue and playback adapters still need to be added and tested against the current Nuvio and Stremio add-on formats.

The token file must be stored on persistent storage. On Render, attach a persistent disk and set `TOKEN_FILE` to a path on that disk (for example `/var/data/youtube-token.enc`). Without persistent storage, a redeploy can remove the saved account connection.

## Google setup

1. Create or select a project in Google Cloud Console.
2. Enable **YouTube Data API v3**.
3. Configure the OAuth consent screen and add your Google account as a test user if the app is in testing.
4. Create an OAuth client ID with application type **Web application**.
5. Add this exact authorized redirect URI:
   `https://YOUR-SERVICE.onrender.com/auth/youtube/callback`
6. Add the client ID, client secret, redirect URI, and encryption key as private environment variables in your hosting service. Do not put secrets in GitHub or share them in chat.

Generate an encryption key locally with:
`node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"`

## Run locally

1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in the values.
4. Run `npm start`.
5. Visit `http://localhost:3000/auth/youtube`.

## API routes

- `GET /health`
- `GET /auth/youtube`
- `GET /auth/youtube/callback` (Google OAuth callback)
- `GET /api/youtube/status`
- `GET /api/youtube/playlists`
- `GET /api/youtube/subscriptions`
- `POST /api/youtube/disconnect`

The personal API routes are currently intended for the Gothika backend integration stage. Do not expose them as public account-data endpoints until app-side authentication/pairing has been implemented.
